// Protean.earth - Shopping Cart Functionality

let cart = [];

// Load cart from localStorage on page load
document.addEventListener('DOMContentLoaded', () => {
    const savedCart = localStorage.getItem('proteanCart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCartUI();
    }
});

// Add item to cart
function addToCart(name, price) {
    const existingItem = cart.find(item => item.name === name);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            name: name,
            price: price,
            quantity: 1
        });
    }
    
    saveCart();
    updateCartUI();
    
    // Show cart sidebar
    openCart();
    
    // Optional: Show notification
    showNotification(`${name} added to cart`);
}

// Remove item from cart
function removeFromCart(index) {
    cart.splice(index, 1);
    saveCart();
    updateCartUI();
}

// Update item quantity
function updateQuantity(index, newQuantity) {
    if (newQuantity < 1) {
        removeFromCart(index);
        return;
    }
    
    cart[index].quantity = newQuantity;
    saveCart();
    updateCartUI();
}

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('proteanCart', JSON.stringify(cart));
}

// Update cart UI
function updateCartUI() {
    const cartCount = document.getElementById('cart-count');
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    
    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    
    // Update cart items
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
    } else {
        cartItems.innerHTML = cart.map((item, index) => `
            <div class="cart-item">
                <div class="cart-item-image">📦</div>
                <div class="cart-item-details">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">$${item.price.toFixed(2)} x ${item.quantity}</div>
                    <button class="remove-item" onclick="removeFromCart(${index})">Remove</button>
                </div>
                <div class="cart-item-total">$${(item.price * item.quantity).toFixed(2)}</div>
            </div>
        `).join('');
    }
    
    // Update total
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotal.textContent = `$${total.toFixed(2)}`;
}

// Toggle cart sidebar
function toggleCart() {
    const sidebar = document.getElementById('cart-sidebar');
    const overlay = document.getElementById('cart-overlay');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

function openCart() {
    const sidebar = document.getElementById('cart-sidebar');
    const overlay = document.getElementById('cart-overlay');
    
    sidebar.classList.add('active');
    overlay.classList.add('active');
}

// Simple notification
function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #2e7d32;
        color: white;
        padding: 15px 25px;
        border-radius: 4px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        font-weight: 500;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideIn 0.3s ease reverse';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Payment Modal Functions
let selectedPaymentMethod = null;

function openCheckoutModal() {
    // Only open if cart is not empty
    if (cart.length === 0) {
        showNotification('Your cart is empty');
        return;
    }
    
    const modal = document.getElementById('checkout-modal');
    modal.classList.add('active');
    selectedPaymentMethod = null;
    updatePayButton();
    
    // Reset selection
    document.querySelectorAll('.payment-method').forEach(el => {
        el.classList.remove('selected');
    });
}

function closeCheckoutModal() {
    const modal = document.getElementById('checkout-modal');
    modal.classList.remove('active');
    selectedPaymentMethod = null;
}

function selectPayment(method) {
    selectedPaymentMethod = method;
    
    // Update UI
    document.querySelectorAll('.payment-method').forEach(el => {
        el.classList.remove('selected');
    });
    
    const selectedEl = document.querySelector(`.payment-method[data-method="${method}"]`);
    if (selectedEl) {
        selectedEl.classList.add('selected');
    }
    
    updatePayButton();
}

function updatePayButton() {
    const payButton = document.getElementById('pay-button');
    if (selectedPaymentMethod) {
        payButton.disabled = false;
        payButton.textContent = `Pay with ${selectedPaymentMethod === 'venmo' ? 'Venmo' : selectedPaymentMethod === 'credit-card' ? 'Credit Card' : 'Google Pay'}`;
    } else {
        payButton.disabled = true;
        payButton.textContent = 'Pay Now';
    }
}

function processPayment() {
    if (!selectedPaymentMethod) {
        showNotification('Please select a payment method');
        return;
    }
    
    if (cart.length === 0) {
        showNotification('Your cart is empty');
        return;
    }
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // Simulate payment processing
    showNotification(`Processing ${selectedPaymentMethod.toUpperCase()} payment of $${total.toFixed(2)}...`);
    
    // In a real implementation, you would integrate with payment APIs
    setTimeout(() => {
        showNotification(`Payment successful! Order confirmed.`);
        // Clear cart
        cart = [];
        saveCart();
        updateCartUI();
        closeCheckoutModal();
        toggleCart(); // Close cart sidebar
    }, 2000);
}

// Initialize payment method selection
document.addEventListener('DOMContentLoaded', () => {
    // Add click handlers to payment methods (already have onclick)
    // Update checkout button in cart
    const checkoutButton = document.querySelector('.cart-footer .btn-primary');
    if (checkoutButton) {
        checkoutButton.onclick = openCheckoutModal;
    }
});

// Make cart functions globally available
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateQuantity = updateQuantity;
window.toggleCart = toggleCart;
window.openCart = openCart;
window.openCheckoutModal = openCheckoutModal;
window.closeCheckoutModal = closeCheckoutModal;
window.selectPayment = selectPayment;
window.processPayment = processPayment;
